package com.project.traini8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Traini8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
